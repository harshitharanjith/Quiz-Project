import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class QuestionActivity extends AppCompatActivity {

    private Button option1, option2, option3, option4, nextQuestion;
    private boolean answerSelected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        // Initialize the buttons
        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);
        option4 = findViewById(R.id.option4);
        nextQuestion = findViewById(R.id.nextQuestion);

        // Set click listeners for answer buttons
        option1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAnswer(option1);
            }
        });

        option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAnswer(option2);
            }
        });

        option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAnswer(option3);
            }
        });

        option4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAnswer(option4);
            }
        });

        // Set click listener for Next Question button
        nextQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle next question logic here (e.g., go to the next question)
                Toast.makeText(QuestionActivity.this, "Next Question", Toast.LENGTH_SHORT).show();
                resetOptions(); // Reset options for the next question
            }
        });
    }

    // Method to handle answer selection
    private void selectAnswer(Button selectedOption) {
        if (!answerSelected) {
            answerSelected = true;
            selectedOption.setBackgroundColor(getResources().getColor(R.color.teal_200)); // Highlight selected option
            disableOtherOptions(selectedOption);
            nextQuestion.setEnabled(true); // Enable the Next Question button
        }
    }

    // Disable other options after selecting an answer
    private void disableOtherOptions(Button selectedOption) {
        if (selectedOption != option1) option1.setEnabled(false);
        if (selectedOption != option2) option2.setEnabled(false);
        if (selectedOption != option3) option3.setEnabled(false);
        if (selectedOption != option4) option4.setEnabled(false);
    }

    // Reset options for the next question
    private void resetOptions() {
        answerSelected = false;
        option1.setEnabled(true);
        option2.setEnabled(true);
        option3.setEnabled(true);
        option4.setEnabled(true);

        // Reset button colors
        option1.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
        option2.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
        option3.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
        option4.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));

        nextQuestion.setEnabled(false); // Disable Next Question button until a new option is selected
    }
}
