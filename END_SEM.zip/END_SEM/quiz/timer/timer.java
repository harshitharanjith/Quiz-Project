import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class TimerActivity extends AppCompatActivity {

    private TextView timerText;
    private static final int START_TIME = 15000; // 15 seconds in milliseconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);

        timerText = findViewById(R.id.timerText);

        // Countdown timer from 15 seconds to 0 seconds
        new CountDownTimer(START_TIME, 1000) {
            public void onTick(long millisUntilFinished) {
                int secondsRemaining = (int) (millisUntilFinished / 1000);
                timerText.setText(String.valueOf(secondsRemaining));
            }

            public void onFinish() {
                timerText.setText("0"); // Display 0 when timer finishes
            }
        }.start();
    }
}
