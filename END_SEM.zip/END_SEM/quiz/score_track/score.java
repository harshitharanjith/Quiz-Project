import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ScoreTrackerActivity extends AppCompatActivity {

    private TextView scoreTextView, questionText;
    private Button option1, option2, option3, option4;
    private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score_tracker);

        // Initialize the views
        scoreTextView = findViewById(R.id.scoreTextView);
        questionText = findViewById(R.id.questionText);
        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);
        option4 = findViewById(R.id.option4);

        // Set click listeners for answer buttons
        option1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Assuming option1 is the correct answer
                updateScore();
                displayCorrectAnswerMessage();
            }
        });

        option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayWrongAnswerMessage();
            }
        });

        option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayWrongAnswerMessage();
            }
        });

        option4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayWrongAnswerMessage();
            }
        });
    }

    // Method to update score
    private void updateScore() {
        score += 10; // Increment score by 10 points for each correct answer
        scoreTextView.setText("Score: " + score); // Update score TextView
    }

    // Method to display message for correct answer
    private void displayCorrectAnswerMessage() {
        Toast.makeText(ScoreTrackerActivity.this, "Correct!", Toast.LENGTH_SHORT).show();
        // Reset question options or load next question as needed
    }

    // Method to display message for wrong answer
    private void displayWrongAnswerMessage() {
        Toast.makeText(ScoreTrackerActivity.this, "Wrong answer, try again!", Toast.LENGTH_SHORT).show();
    }
}
