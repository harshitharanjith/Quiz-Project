import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Set up card click listeners
        Button cardNature = findViewById(R.id.cardNature);
        Button cardScience = findViewById(R.id.cardScience);
        Button cardComputerScience = findViewById(R.id.cardComputerScience);

        cardNature.setOnClickListener(v -> startQuiz("Nature"));
        cardScience.setOnClickListener(v -> startQuiz("Science"));
        cardComputerScience.setOnClickListener(v -> startQuiz("Computer Science"));
    }

    private void startQuiz(String topic) {
        Intent intent = new Intent(HomeActivity.this, QuizActivity.class);
        intent.putExtra("topic", topic);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.menu_history) {
            startActivity(new Intent(HomeActivity.this, HistoryActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
